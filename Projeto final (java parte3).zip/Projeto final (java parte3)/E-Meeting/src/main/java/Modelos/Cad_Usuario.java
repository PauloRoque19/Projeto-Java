/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;



/**
 *
 * @author junior
 */
public class Cad_Usuario extends Dados {

    public Cad_Usuario() {
    }
    

    @Override
    public String toString() {
        
        String str;
        
        str = "---------------- Relatorio de Cadastro de Usuario -------------------"+
                
                                 "\n Nome Completo = "+getNome()+
                                 "\n E-mail = "+getEmail()+
                                 "\n CPF = "+getCpf()+
                                 "\n Nome de Login = "+getNomeLogin()+
                                 "\n Senha de Login = "+ getSenhaLogin();
              
        return str;
    }

    @Override
    public String lista_de_Sala() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String listaReuniao_Comum() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public String listaUsuario(){
        
        try{
            
           FileWriter fw = new FileWriter("Lista_de_Usuario.txt",true);
           PrintWriter pw = new PrintWriter(fw);
           pw.println("Nome = "+ getNome());
           pw.println("E-mail = "+ getEmail());
           pw.println("CPF  = "+ getCpf());
           pw.println("Nome de Login  = "+ getNomeLogin());
           pw.println("Senha  = "+ getSenhaLogin());
           pw.flush();
           pw.close();
           fw.close();
        
        } catch(IOException ex){
            Logger.getLogger(Dados.class.getName()).log(Level.SEVERE, null, ex);
        }
        return  null;
    
    }

    @Override
    public String lista_de_Reuniao_Coordenador() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
