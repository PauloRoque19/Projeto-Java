/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.in;
import java.nio.Buffer;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author junior
 */
public abstract class  Dados implements Infor {
    
    private String pauta;
    private String ata;
    private String tema;
    private String nP;
    private String presenca;
    private String dia;
    private String hora;
    private String horaFim;
    private String proprietario;
    private String sala;
    private String endereco;
    private String sugestao;
    private String nome;
    private String email;
    private String cpf;
    private String nomeLogin;
    private String senhaLogin;
    private String confSenha;
    private String usuario;
    private String senha;

    public Dados() {
    }

    public Dados(String pauta,String endereco,String usuario,String senha, String ata, String tema, String nP, String presenca, String dia, String hora, String horaFim, String proprietario, String sala, String sugestao, String nome, String email, String cpf, String nomeLogin, String senhaLogin, String confSenha) {
        this.pauta = pauta;
        this.ata = ata;
        this.tema = tema;
        this.nP = nP;
        this.presenca = presenca;
        this.endereco = endereco;
        this.dia = dia;
        this.hora = hora;
        this.horaFim = horaFim;
        this.proprietario = proprietario;
        this.sala = sala;
        this.sugestao = sugestao;
        this.nome = nome;
        this.email = email;
        this.cpf = cpf;
        this.nomeLogin = nomeLogin;
        this.senhaLogin = senhaLogin;
        this.confSenha = confSenha;
        this.usuario = usuario;
        this.senha = senha;
    }

    public String getEndereco(){
        return endereco;
    }
    
    public void setEndereco(String endereco){
        this.endereco = endereco;
    }

    /**
     * @return the pauta
     */
    public String getPauta() {
        return pauta;
    }

    /**
     * @param pauta the pauta to set
     */
    public void setPauta(String pauta) {
        this.pauta = pauta;
    }

    /**
     * @return the ata
     */
    public String getAta() {
        return ata;
    }

    /**
     * @param ata the ata to set
     */
    public void setAta(String ata) {
        this.ata = ata;
    }

    /**
     * @return the tema
     */
    public String getTema() {
        return tema;
    }

    /**
     * @param tema the tema to set
     */
    public void setTema(String tema) {
        this.tema = tema;
    }

    /**
     * @return the nP
     */
    public String getnP() {
        return nP;
    }

    /**
     * @param nP the nP to set
     */
    public void setnP(String nP) {
        this.nP = nP;
    }

    /**
     * @return the presenca
     */
    public String getPresenca() {
        return presenca;
    }

    /**
     * @param presenca the presenca to set
     */
    public void setPresenca(String presenca) {
        this.presenca = presenca;
    }

    /**
     * @return the dia
     */
    public String getDia() {
        return dia;
    }

    /**
     * @param dia the dia to set
     */
    public void setDia(String dia) {
        this.dia = dia;
    }

    /**
     * @return the hora
     */
    public String getHora() {
        return hora;
    }

    /**
     * @param hora the hora to set
     */
    public void setHora(String hora) {
        this.hora = hora;
    }

    /**
     * @return the horaFim
     */
    public String getHoraFim() {
        return horaFim;
    }

    /**
     * @param horaFim the horaFim to set
     */
    public void setHoraFim(String horaFim) {
        this.horaFim = horaFim;
    }

    /**
     * @return the proprietario
     */
    public String getProprietario() {
        return proprietario;
    }

    /**
     * @param proprietario the proprietario to set
     */
    public void setProprietario(String proprietario) {
        this.proprietario = proprietario;
    }

    /**
     * @return the sala
     */
    public String getSala() {
        return sala;
    }

    /**
     * @param sala the sala to set
     */
    public void setSala(String sala) {
        this.sala = sala;
    }

    /**
     * @return the sugestao
     */
    public String getSugestao() {
        return sugestao;
    }

    /**
     * @param sugestao the sugestao to set
     */
    public void setSugestao(String sugestao) {
        this.sugestao = sugestao;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the cpf
     */
    public String getCpf() {
        return cpf;
    }

    /**
     * @param cpf the cpf to set
     */
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    /**
     * @return the nomeLogin
     */
    public String getNomeLogin() {
        return nomeLogin;
    }

    /**
     * @param nomeLogin the nomeLogin to set
     */
    public void setNomeLogin(String nomeLogin) {
        this.nomeLogin = nomeLogin;
    }

    /**
     * @return the senhaLogin
     */
    public String getSenhaLogin() {
        return senhaLogin;
    }

    /**
     * @param senhaLogin the senhaLogin to set
     */
    public void setSenhaLogin(String senhaLogin) {
        this.senhaLogin = senhaLogin;
    }

    /**
     * @return the confSenha
     */
    public String getConfSenha() {
        return confSenha;
    }

    /**
     * @param confSenha the confSenha to set
     */
    public void setConfSenha(String confSenha) {
        this.confSenha = confSenha;
    }
    
    public String getUsuario(){
        return usuario;
    }
    public void setUsuario(String usuario){
        this.usuario = usuario;
    }
    
    public String getSenha(){
        return senha;
    }
    public void setSenha(String senha){
        this.senha = senha;
    }
    
      
}    
