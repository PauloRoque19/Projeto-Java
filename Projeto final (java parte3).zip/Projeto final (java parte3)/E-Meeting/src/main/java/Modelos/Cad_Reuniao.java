/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;



/**
 *
 * @author junior
 */
public class Cad_Reuniao extends Dados {

    public Cad_Reuniao() {
    }
    
    

    @Override
    public String toString() {
        
        String str;
        str = "------------ Relatorio de Cadastro de Reunião -------------"+
                
                       "\n Pauta = "+getPauta()+
                       "\n Ata = "+getAta()+ 
                       "\n Tema = "+getTema()+
                       "\n Numero de Participantes = "+getnP()+
                       "\n Presença = "+getPresenca()+
                       "\n Dia = "+getDia()+
                       "\n Hora do Inicio = "+getHora()+
                       "\n Hora do Fim = "+getHoraFim()+
                       "\n Sala = "+ getSala()+
                       "\n Proprietario da Reunião = "+getProprietario()+
                       "\n Sugestão de Local = "+getSugestao();
        return str;
    }

    @Override
    public String lista_de_Sala() {
 
        try{
            
           FileWriter fw = new FileWriter("Lista_de_Sala.txt",true);
           PrintWriter pw = new PrintWriter(fw);
           pw.println("Nome da Sala = "+ getSala());
           pw.println("Endereço da Sala = "+ getEndereco());
           pw.flush();
           pw.close();
           fw.close();
        
        } catch(IOException ex){
            Logger.getLogger(Cad_Reuniao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return  null;
    }

    public String  listaReuniao_Comum(){
        
        try{
            
           FileWriter fw = new FileWriter("Lista_de_Reuniao_Comum.txt",true);
           PrintWriter pw = new PrintWriter(fw);
           pw.println("Pauta = "+ getPauta());
           pw.println("Ata = "+ getAta());
           pw.println("Tema  = "+ getTema());
           pw.println("Nª de Participantes  = "+ getnP());
           pw.println("Presença  = "+ getPresenca());
           pw.println("Dia  = "+ getDia());
           pw.println("Hora  = "+ getHora());
           pw.println("Hora do Fim da Reunião  = "+ getHoraFim());
           pw.println("Proprietario  = "+ getProprietario());
           pw.println("Sala  = "+ getSala());
           pw.println("Sugestão de Local  = "+ getSugestao());
           pw.flush();
           pw.close();
           fw.close();
        
        } catch(IOException ex){
            Logger.getLogger(Dados.class.getName()).log(Level.SEVERE, null, ex);
        }
        return  null;
    
    }
   
    public String lista_de_Reuniao_Coordenador() {
        
        try{
        
           FileWriter fw1 = new FileWriter("Lista_de_Reuniao_Coordenador.txt",true);
           PrintWriter pw = new PrintWriter(fw1);
           pw.println("Pauta = "+ getPauta());
           pw.println("Ata = "+ getAta());
           pw.println("Tema  = "+ getTema());
           pw.println("Nª de Participantes  = "+ getnP());
           pw.println("Presença  = "+ getPresenca());
           pw.println("Dia  = "+ getDia());
           pw.println("Hora  = "+ getHora());
           pw.println("Hora do Fim da Reunião  = "+ getHoraFim());
           pw.println("Proprietario  = "+ getProprietario());
           pw.println("Sala  = "+ getSala());
           pw.println("Sugestão de Local  = "+ getSugestao());
           pw.flush();
           pw.close();
           fw1.close();
           
           } catch(IOException ex){
             Logger.getLogger(Dados.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return  null;
    
   }

    @Override
    public String listaUsuario() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
