/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

// pacotes
import View.TelaLogin;
import javax.swing.JOptionPane;
import View.CadastrarUsuario;

/**
 *
 * @author junior
 */
public class CadastrarUser extends TelaLogin{
    
    //Atributos da Classe..
    private String nomeCompleto;
    private String email;
    private String cpf;
    private String nomeLogin;
    private String senha;
    private String barra;
    
    // Construtor Vazio
    public CadastrarUser() {
    }
    // Construtor com Parametro
    public CadastrarUser(String nomeCompleto, String email, String cpf, String nomeLogin, String senha) {
        this.nomeCompleto = nomeCompleto;
        this.email = email;
        this.cpf = cpf;
        this.nomeLogin = nomeLogin;
        this.senha = senha;
    }
    
    //Encapsulamento...
    public String getNomeCompleto() {
        return nomeCompleto;
    }

    public void setNomeCompleto(String nomeCompleto) {
        this.nomeCompleto = nomeCompleto;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getCpf() {
        return cpf;
    }

    public void setNomeLogin(String nomeLogin) {
        this.nomeLogin = nomeLogin;
    }

    public String getNomeLogin() {
        return nomeLogin;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
 
    //to String
   public String toString(){
       String str;
       str = "\n ############Cadastrado#############"+
                 "\n # Nome Completo = "+nomeCompleto+        
                 "\n # E-mail = "+email+           
                 "\n # CPF = "+cpf+
                 "\n # Nome de Login = "+nomeLogin+
                 "\n # Senha = "+senha;
               
              
       return str;
   }
  
} 