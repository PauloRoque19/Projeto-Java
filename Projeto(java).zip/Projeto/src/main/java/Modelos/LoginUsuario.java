/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;
import View.TelaLogin;
import javax.swing.JOptionPane;
/**
 *
 * @author junior
 */
public class LoginUsuario extends CadastrarUser{
    
    // atributos
    private String login;
    private String senha;

    // construtor
    public LoginUsuario() {
    }
   
    // construtor com parametros
    public LoginUsuario(String login, String senha) {
        this.login = login;
        this.senha = senha;
    }
    
    // Encapsulamento
    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
}
